	#include <stdio.h>
	#include <stdlib.h>
	#include "Baralho.h"
	/* função de inicialização */
	TpCartaBaralho* inicializa(){
		return NULL;
	}

	/* função de inserção  a inserção ocorre sempre no inicio*/
	TpCartaBaralho *Inserir(TpCartaBaralho *baralho,int naipe, int number){
		TpCartaBaralho * novo =(TpCartaBaralho*) malloc(sizeof(TpCartaBaralho));
		novo->naipe = naipe;
		novo->number = number;
		novo->right = baralho; // torna baralho como 2° elemento da lista

		if(baralho!= NULL){
			baralho->left = novo; // insere sempre no inicio da lista tornando o novo sempre o 1° elemento
		}
		//torna o novo como 1° elemento da lista
		novo->left = NULL;
		return novo;
	}

	void Embaralha(TpCartaBaralho* baralho,int *naipe,int *number){
		TpCartaBaralho* aux = baralho;
		int n=2;
		srand(time(NULL));
		n = rand()%cartas_restantes;
		for(int i=1;i<=n;i++){
			if(i==n){
				//puts("------------------------------------------------------");
				// /printf("Posição da lista{%d}\n",n );
				//printf("Naipe {%d} \tNumero {%d}\n",aux->naipe,aux->number);
				*naipe=aux->naipe;
				*number=aux->number;
				cartas_restantes--;


			}
			aux=aux->right;
		}baralho = drop(baralho,aux);
	}

	void imprime (TpCartaBaralho* baralho){
		TpCartaBaralho* novo = baralho; // novo aponta para o elemento inicial
		int cont=0;// lista não está vazia
		do {
			printf("Naipe {%d} \tNumero {%d}\n",novo->naipe,novo->number);
			//printf("%d\n",40%100 );
			novo = novo->right; 	// avança para o próximo nó
			cont ++;

		}while(novo != NULL);printf("Total de cartas{%d}\n",cont );
	}

	TpCartaBaralho* drop(TpCartaBaralho* baralho,TpCartaBaralho* aux){
		if(aux->right!=NULL)// ultimo
			aux->right->left=aux->left;

		if (aux!=baralho){//todos meio
			aux->left->right=aux->right;
			}
		else{
			baralho=aux->right;

		}

		free(aux);
		return baralho;
	}

	TpCartaBaralho *jogaMesa(TpCartaBaralho *mesa,TpCartaBaralho *player1,TpCartaBaralho *comp){
		TpCartaBaralho * novo = player1;
		printf("------------Cartas da Mesa----------------------------\n");
		imprime(mesa);
		puts("------------------------------------------------------");

		puts("Escolha a posição que contem a carta que deseja jogar{1(é a mais de cima),2,3(é a mais de baixo)}");
		int entradaUS=0;
		scanf("%d",&entradaUS );
		puts("------------------------------------------------------");

		for(int i=1; i<=3; i++){
			if(i==entradaUS){
				mesa = Inserir(mesa,novo->naipe,novo->number);
				player1= drop(player1,novo);
				imprime(mesa);
				imprime(player1);

			}
			novo=novo->right;
		}

		return 0;
	}

	TpCartaBaralho *recolheMonte(TpCartaBaralho *mesa,TpCartaBaralho *player1,TpCartaBaralho *comp,TpCartaBaralho *baralho,TpCartaBaralho *montePlayer1,TpCartaBaralho *monteComp){
		TpCartaBaralho * novo = mesa;
		printf("------------Cartas da Mesa----------------------------\n");
		imprime(mesa);
		puts("------------------------------------------------------");
	return novo;
	}
